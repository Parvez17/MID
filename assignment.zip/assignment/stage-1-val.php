<?php

//validation function for text field...........................

 function validation1($fieldName,$value,$name) {
 	  global  $existValue;
 	 if(trim($value)=="" || preg_match('[^a-zA-Z]',$value))
 	 {
 	 	error_flag1($fieldName,$value);
 	 	$existValue[$name]=0;
 	 }
 	 else {
 	 	$existValue[$name]=1;
 	 	setcookie($name,$value);
 	 }
 	}
 	
//error flag function for text field...........................

 function error_flag1($fieldName,$value) {
	global $errors;
	$errorString="please enter valid ".$fieldName;
	
	$errors[]=$errorString;
 } 	

//validation function for select field.........................

 function validation2($fieldName,$value,$name) {
 	global $existValue;
 	if(trim($value)=='SELECT-' || trim($value)=="")
 	{
 		
 		error_flag2($fieldName,$value);
 		$existValue[$name]=0;
 	}
 	 else {
 	 	$existValue[$name]=1;
 	 	setcookie($name,$value);
 	 }
 }


//error flag function for select field...........................

 function error_flag2($fieldName,$value) {
    global $errors;
	$errorString="please select a ".$fieldName;
	$errors[]=$errorString;
 } 	
 
 
 function validation3($value,$name) {
 	global $existValue;
 		if(trim($value)=='-SELECT-' || trim($value)=="")
 	{
 		$existValue[$name]=0;
		
 	}
 	 else {
 	 	$existValue[$name]=1;
		
 	 	setcookie($name,$value);
 	 }
 }

//values .......................................

 $p=& $_POST;
 validation3($p['appin'],'appin');
 validation3($p['passtype'],'passtype');

 //$p['delType'];
 
 validation1('Name',$p['na'],'na');
 validation1('GivenName',$p['gn'],'gn');
 validation1('SurName',$p['sn'],'sn');
 validation1('FaterName',$p['fn'],'fn');
 validation3($p['fnationality'],'fnationality');
 validation2('FatherProfession',$p['fprofession'],'fprofession');  
 validation1('MotherName',$p['mn'],'mn');
 validation3($p['mnationality'],'mnationality');
 validation2('MotherProfession',$p['mprofession'],'mprofession');
 validation3($p['spn'],'spn');
 validation3($p['snationality'],'snationality');
 validation3($p['sprofession'],'sprofession');
 validation2('MaritalStatus',$p['ms'],'ms');
 validation2('App;icant Profession',$p['aprofession'],'aprofession');
 validation3($p['cb'],'cb');
 validation2('BirthID',$p['bid'],'bid');
 //validation3($p['dob'],'dob');

// $p['gender'];

 validation3($p['nid'],'nid');
 validation3($p['tid'],'tid');
 validation2('Religion',$p['religion'],'religion');
 validation3($p['cnationality'],'cnationality');
 validation3($p['ctstatus'],'ctstatus');
 validation3($p['vh'],'vh');
 validation3($p['rbs'],'rbs');
 validation2('District',$p['dis'],'dis');
 validation2('Police Station',$p['ps'],'ps');
 validation3($p['po'],'po');
 validation3($p['pvh'],'pvh');
 validation3($p['prbs'],'prbs');
 validation2('Permanent District',$p['pdis'],'pdis');
 validation2('Permanent Police Station',$p['pps'],'pps');
 validation2('Permanent Post Office',$p['ppo'],'ppo');

// $p['dualct'];

 
 
 //$height=$p['cm']+$p['inch'];
 
 
   
   //validation1('Height',$height,'height');
   
   validation1('Email', $p['email'],'email');
  



  setcookie('existValue',json_encode($existValue));
    
   if(!empty($errors))
   {
   	$ew="fieldError";

   setcookie($ew,json_encode($errors));
  // setcookie('check',json_encode($fieldsOfError));
 
  }
  else{
	   setcookie('fieldError','',time()-3600);
  }
  
 	header('Location: http://localhost/assignment/pages/stage2.php');
?>