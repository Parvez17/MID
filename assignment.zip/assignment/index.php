<!DOCTYPE html>
<html>
	<head>
		<title>Application Form-Stage 1</title>
	</head>
	<body>
	 
		<h1> PASSPORT APPLICATION - STAGE 1 <h1>
		<h4 style="color:red"><i>Before filling the online application form read the <a href ="">guidlines</a> carefully.</i></h6>
		<h4> Fields marked with <font color="red">(*)</font> are mendatory. </h4>
		<hr>
		<?php
        if(isset($_COOKIE['fieldError']))
        {
          $e=json_decode($_COOKIE['fieldError'],true);
          $i=count($e);
          echo "<fieldset>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e[$j] </br>";
          }
          echo "</fieldset>";
        }
        if(isset($_COOKIE['existValue'])) {
        	 $existValue=json_decode($_COOKIE['existValue'], true);
        }
		else {
        	$existValue=0;
        }
       ?>
		<form action="stage-1-val.php" method="POST">
		<table  border = "0" width="100%" align = "left" bgcolor="#eff2f7">
		<tr>
		<td style = "vertical-align:top">
			<table border = "0" width="" align = "left">
			
				<tr>
					<td>
						 Applying in: <font color="red"><sup>*</sup></font> 
					</td>
					<td>
						<select name = "appin" value="">
							<option><?php if($existValue!=0)
                                      {
                                      	if($existValue['appin']==1) echo $_COOKIE['appin'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							
							<option >Bangladesh</option>
							<option>Barbados</option>
							<option>Belarus</option>
							
							
							
						</select>
						
					</td>
				
				</tr>
				<tr>
					<td>
						<p>Application Type: 
					</td>
					<td>
						<b>NEW APPLICATION</b>
					</td>
				</tr>
				<tr>
					<td>
						Passport Type: <font color="red"><sup>*</sup></font>
					</td>
					<td>
						<select name= passtype value="">
							<option value=""><?php if($existValue!=0)
                                      {
                                      	if($existValue['passtype']==1) echo $_COOKIE['passtype'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							<option >ORDINARY</option>
							<option>DIPLOMATIC</option>
							<option>OFFICIAL</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						Delivery Type:
					</td>
					<td>
						<input type = "radio" name = "de" mark = "unchecked">Regular</input><br>
						<input type = "radio" name = "de" mark = "unchecked">Express</input>
					</td>
				</tr>
				<tr>	
					<tr>
						<th align = "left"><h3>Personal Information</h3></th>
					</tr>
					<td>
						Name of<br>applicant:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<input type = "text" name = "na" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['na']==1) echo $_COOKIE['na'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>
					<td>
						First Part<br>(Given Name):
					</td>
					<td>
							<input type = "text" name = "gn" value= "<?php if($existValue!=0)
                                      {
                                      	if($existValue['gn']==1) echo $_COOKIE['gn'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
				
					</td>
				</tr>
				<tr>
					<td>
						Second Part<br>(Surname):<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
							<input type = "text" name = "sn" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['sn']==1) echo $_COOKIE['sn'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
				
					</td>
				</tr>
				<tr>
					<td colspan = "2">
					<br>
					<br>
						Guardian <input type = "checkbox" name ="tk"> <font color = "red"><i>"Tick</i></font> only if Applicant is legally adapted
					</td>
				</tr>
				<tr>
					<td>
						Father's name:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
							<input type = "text" name = "fn" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['fn']==1) echo $_COOKIE['fn'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
				
					</td>
				</tr>
				<tr>
					<td>
						Father's Nationality:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<select name="fnationality" value="">
							  <option><?php if($existValue!=0)
                                      {
                                      	if($existValue['fnationality']==1) echo $_COOKIE['fnationality'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							  
							  <option>Bangladeshi</option>
							  <option>Barbadian</option>
							  <option>Barbudans</option>
							  <option>Batswana</option>
							  <option>Belarusian</option>
							  <option>Belgian</option>
							  <option>Belizean</option>
							 
							</select>
				
					</td>
				</tr>
				<tr>
					<td>
						Father's Profession:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
							<select name = "fprofession" value="">
								<option><?php if($existValue!=0)
                                      {
                                      	if($existValue['fprofession']==1) echo $_COOKIE['fprofession'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
								<option>EMPLOYEE</option>
								<option>BUSINESS</option>
							</select>
				
					</td>
				</tr>
				<tr>
					<td>
						Mothers's name:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
							<input type = "text" name = "mn" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['mn']==1) echo $_COOKIE['mn'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
				
					</td>
				</tr>
				<tr>
					<td>
						Mothers's Nationality:<font color ="red"><sup>(*)</sup></font>
					</td>
					
					<td>
						<select name="mnationality" value="">
							  <option><?php if($existValue!=0)
                                      {
                                      	if($existValue['mnationality']==1) echo $_COOKIE['mnationality'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							  
							  <option >Bangladeshi</option>
							  <option >Barbadian</option>
							  <option >Barbudans</option>
							  <option >Batswana</option>
							  <option >Belarusian</option>
							  <option>Belgian</option>
							  <option >Belizean</option>
							  <option>Beninese</option>
							  
							</select>
				
					</td>
				
					
				</tr>
				<tr>
					<td>
						Mothers's Profession:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
							<select name = "mprofession" value="">
								<option><?php if($existValue!=0)
                                      {
                                      	if($existValue['mprofession']==1) echo $_COOKIE['mprofession'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
								<option >HOUSEWIFE</option>
								<option >EMPLOYEE</option>
								<option >BUSINESS</option>
							</select>
				
					</td>
				</tr>
				<tr>
					<td>
						Spouse's Name
					</td>
					<td>
							<input type "text" name ="spn" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['spn']==1) echo $_COOKIE['spn'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
				
					</td>
				</tr>
				
				<tr>
					<td>
						Spouse's Nationality:
					</td>
					<td>
						<select name="snationality" value="">
							  <option ><?php if($existValue!=0)
                                      {
                                      	if($existValue['snationality']==1) echo $_COOKIE['snationality'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-';  ?>-</option>
							  
							  <option>Bahamian</option>
							  <option>Bahraini</option>
							  <option>Bangladeshi</option>
							  <option>Barbadian</option>
							  <option>Barbudans</option>
							  <option>Batswana</option>
							  <option>Belarusian</option>
							  <option>Belgian</option>
							  
							</select>
				
					</td>
				</tr>
				<tr>
					<td>
						Spouse's Profession:
					</td>
					<td>
							<select name = "sprofession" value="">
								<option ><?php if($existValue!=0)
                                      {
                                      	if($existValue['sprofession']==1) echo $_COOKIE['sprofession'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
								<option>HOUSEWIFE</option>
								<option>EMPLOYEE</option>
								<option>BUSINESS</option>
							</select>
				
					</td>
				</tr>
				<tr>
					<td>
						Maritual Stattus:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<select name = "ms" value="">
								<option ><?php if($existValue!=0)
                                      {
                                      	if($existValue['ms']==1) echo $_COOKIE['ms'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
								<option >SINGLE</option>
								<option >MARRIED</option>
								
						</select>
					</td>
				</tr>
				<tr>
					<td>
						Applicant's Profession:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<select name = "aprofession" value="">
							<option><?php if($existValue!=0)
                                      {
                                      	if($existValue['aprofession']==1) echo $_COOKIE['aprofession'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							<option >HOUSEWIFE</option>
							<option >EMPLOYEE</option>
							<option >BUSINESS</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						Country of Birth:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<select name = "cb"  value="">
							<option ><?php if($existValue!=0)
                                      {
                                      	if($existValue['cb']==1) echo $_COOKIE['cb'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							
							<option >Bahrain</option>
							<option >Bangladesh</option>
							<option >Barbados</option>
							<option >Belarus</option>
							<option >Belgium</option>
							<option >Zambia</option>
							<option >Zimbabwe</option>
						</select>
					
					</td>
				</tr>
			</table>
			</td>
			<td>
			<table border = "0" width="" align = "left">
				<tr>
					<td>
						Date of Birth:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<input type = "text" name = "dob" value=" <?php if($existValue!=0)
                                      {
                                      	if($existValue['dob']==1) echo $_COOKIE['dob'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				
				</tr>
				<tr>
					<td>
						Gender:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<input type = "radio" name = "agender"  mark = "unchecked">Male</input><br>
						<input type = "radio" name = "agender"  mark = "unchecked">Female</input><br>
						<input type = "radio" name = "agender"  mark = "unchecked">Others</input>
					</td>
				
				</tr>
				<tr>
					<td>
						Birth ID No:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<input type = "text" name = "bid" value= "<?php if($existValue!=0)
                                      {
                                      	if($existValue['bid']==1) echo $_COOKIE['bid'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				
				</tr>
				<tr>
					<td>
						National ID No:
					</td>
					<td>
						<input type = "text" name = "nid" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['nid']==1) echo $_COOKIE['nid'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				
				</tr>
				
				<tr>
					<td>
						Tax ID No:
					</td>
					<td>
						<input type = "text" name = "tid" value=" <?php if($existValue!=0)
                                      {
                                      	if($existValue['tid']==1) echo $_COOKIE['tid'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				
				<tr>
					<td>
						Height:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<input type = "text" name = "cm" value="" > cm 
						<input type = "text" name = "inch" value="">inch
					</td>
				
				</tr>
				<tr>
					<td>
						Religion:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<select name = "religion" value="">
							<option ><?php if($existValue!=0)
                                      {
                                      	if($existValue['religion']==1) echo $_COOKIE['religion'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							<option >ISLAM</option>
							<option >HINDU</option>
							<option >BUDDHA</option>
							<option >CHRISTIAN</option>
						</select>
					</td>
				
				</tr>
				<tr>
					<td>
						Email:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<input type = "text" name = "email" value= "<?php if($existValue!=0)
                                      {
                                      	if($existValue['email']==1) echo $_COOKIE['email'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">  
						
					</td>
				
				</tr>
				<tr>	
					<tr>
						<th align = "left"><h3>Citizenship Information</h3></th>
					</tr>
					<td>
						Nationality:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<select name="cnationality" value="">
							  <option ><?php if($existValue!=0)
                                      {
                                      	if($existValue['cnationality']==1) echo $_COOKIE['cnationality'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							  
							  <option>Bangladeshi</option>
							  <option>Barbadian</option>
							  <option>Barbudans</option>
							  
							</select>
				
					</td>
				</tr>
				<tr>
					<td>
						Citizenship Status:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<select name = "ctstatus" value="">
							<option ><?php if($existValue!=0)
                                      {
                                      	if($existValue['ctstatus']==1) echo $_COOKIE['ctstatus'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-';  ?></option>
							<option>BIRTH</option>
							<option >PARENTAGE</option>
							<option >MIGRATION</option>
							<option>NATURALIZATION</option>
							<option>OTHERS</option>
						</select>
					</td>
				
				</tr>
				<tr>
					<td>
						Dual Citizenship:<font color ="red"><sup>(*)</sup><font>
					</td>
					<td>
						<input type = "radio" name = "DC"  mark = "unchecked">Yes</input><br>
						<input type = "radio" name = "DC"  mark = "unchecked">No</input>
						
					</td>
				
				</tr>
				<tr>	
					<tr>
						<th align = "left"><h3>Present Address</h3></th>
					</tr>
					<td>
						Village/House:
					</td>
					<td>
						<input type = "text" name = "vh" value=" <?php if($existValue!=0)
                                      {
                                      	if($existValue['vh']==1) echo $_COOKIE['vh'];
                                       else echo '';
                                       }
                                        else echo ''; ?>">
					</td>
				</tr>
				<tr>	
					
					<td>
						Road/Block/Sector:
					</td>
					<td>
						<input type = "text" name = "rbs" value=" <?php if($existValue!=0)
                                      {
                                      	if($existValue['rbs']==1) echo $_COOKIE['rbs'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>	
					
					<td>
						District:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<input type = "text" name = "dis" value=" <?php if($existValue!=0)
                                      {
                                      	if($existValue['dis']==1) echo $_COOKIE['dis'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>	
					
					<td>
						Police Station:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<input type = "text" name = "ps" value= "<?php if($existValue!=0)
                                      {
                                      	if($existValue['ps']==1) echo $_COOKIE['ps'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>
					<td>
						Post Office:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<input type = "text" name = "po" value= "<?php if($existValue!=0)
                                      {
                                      	if($existValue['nid']==1) echo $_COOKIE['nid'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>	
					<tr>
						<th align = "left"><h3>Permanent Address</h3></th>
					</tr>
					<td>
						Village/House:
					</td>
					<td>
						<input type = "text" name = "pvh" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['pvh']==1) echo $_COOKIE['pvh'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>	
					
					<td>
						Road/Block/Sector:
					</td>
					<td>
						<input type = "text" name = "prbs" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['prbs']==1) echo $_COOKIE['prbs'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>	
					
					<td>
						District:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<input type = "text" name = "pdis"  value=" <?php if($existValue!=0)
                                      {
                                      	if($existValue['pdis']==1) echo $_COOKIE['pdis'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>	
					
					<td>
						Police Station:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<input type = "text" name = "pps" value="<?php if($existValue!=0)
                                      {
                                      	if($existValue['pps']==1) echo $_COOKIE['pps'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				<tr>
					<td>
						Post Office:<font color ="red"><sup>(*)</sup><font>

					</td>
					<td>
						<input type = "text" name = "ppo" value=" <?php if($existValue!=0)
                                      {
                                      	if($existValue['ppo']==1) echo $_COOKIE['ppo'];
                                       else echo '';
                                       }
                                        else echo '';  ?>">
					</td>
				</tr>
				
			</table>
			</td>
			</tr>
			<tr>
					<td></td>
					<td align = "right"><br> <input type = "button" value= "SAVE NOW & CONTINUE IN FUTURE" >
					<input type = "submit" value = "SAVE & NEXT" >
				</tr>
			</table>
		</form>
	</body>
</html>