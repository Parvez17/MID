<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Final Stage</title>
	<link rel="stylesheet" href="">
</head>
<script type="text/javascript">
function nlink()
        {
            location.replace("http://localhost/assignment/pages/fileMaker.php");
            
        }
        
function plink()
        {
            location.replace("http://localhost/assignment/pages/page3.php");
            
        }
</script>


 <?php
        
        if(isset($_COOKIE['existValue'])) {
        	 $existValue=json_decode($_COOKIE['existValue'], true);
        }
        else {
        	$existValue=0;
        }
        
        if(isset($_COOKIE['existValue2'])) {
        	 $existValue2=json_decode($_COOKIE['existValue2'], true);
        }
        else {
        	$existValue2=0;
        }
        
       
        if(isset($_COOKIE['existValue3'])) {
        	 $existValue3=json_decode($_COOKIE['existValue3'], true);
        }
        else {
        	$existValue3=0;
        }
       ?>
<body>
	<div class="">
		<h3>PASSPORT APPLICATION - REVIEW ENROLMENT SUMMARY</h3>
		<p style="color:#338099"><b>Online application ID: OA0000004008216</b></p>
		<p style="color:green">Enrolment date: 26/06/2018</p>
		<p><i><h5 style="color:red">Reminder before submitting your application.</h5></i></p>
        <ul>
        	<li>
        		<p><i>After you click submit,you are not allowed to modify your information.</i></p>
        	</li>
        	<li>
        		<p><i>Please visit <b>BAGERHAT Branch</b> on any working day within the next 15 days for biometric capture except government holidy.</i></p> 
        	</li>
        </ul> 
		<hr>
		<form action="" method="">
			<fieldset>
				<table style="width:50%; float:left;  border-spacing:8px;">
					<tr>
						<td><h3 style="color:#338099">Personal Information Summary</h3></td>
					</tr>
					<tr>
						<td>Name of Applicant:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['na']==1) echo $_COOKIE['na'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>First Part(Given Name):</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['gn']==1) echo $_COOKIE['gn'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Second Part(Surname):</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['sn']==1) echo $_COOKIE['sn'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					
					<tr>
						<td>Gender:</td>
						<td>Male</td>
					</tr>
					<tr>
						<td>Nationality:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['cnationality']==1) echo $_COOKIE['cnationality'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Date of Birth:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['dob']==1) echo $_COOKIE['dob'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Place of Birth:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['cb']==1) echo $_COOKIE['cb'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Father's Name:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['fn']==1) echo $_COOKIE['fn'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Mother's Name:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['mn']==1) echo $_COOKIE['mn'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Spouse's Name:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['spn']==1) echo $_COOKIE['spn'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>National ID No:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['nid']==1) echo $_COOKIE['nid'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Birth ID No:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['bid']==1) echo $_COOKIE['bid'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Old Passport No:</td>
						<td><?php if($existValue2!=0)
                                      {
                                      	if($existValue2['passNo']==1) echo $_COOKIE['passNo'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>


				</table>

				<!-- 2nd table -->
				<table style="width:50%; float:left;  border-spacing:8px;">
					<tr>
						<td><h3 style="color:#338099">Passport Information Summary</h3></td>
					</tr>
					<tr>
						<td>Applying in:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['appin']==1) echo $_COOKIE['appin'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Passport Type:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['passtype']==1) echo $_COOKIE['passtype'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Application Type:</td>
						<td>NEW APPLICATION</td>
					</tr>
					<tr>
						<td><h3 style="color:#338099">Contact Information System</h3></td>
					</tr>
					<tr>
						<td>Mobile No:</td>
						<td><?php if($existValue2!=0)
                                      {
                                      	if($existValue2['mobno']==1) echo $_COOKIE['mobno'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Present Address:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['dis']==1) echo $_COOKIE['vh']."," .$_COOKIE['rbs']."," . $_COOKIE['ps'].",". $_COOKIE['po'].", ". $_COOKIE['dis'].","."Bangladesh.";
                                       else echo '';
                                       }
                                        else echo '';  ?> </td>
					</tr>
					<tr>
				        <td>Parmanent Address:</td>
				        <td><?php if($existValue!=0)
                                      {
                                      	if($existValue['pdis']==1) echo $_COOKIE['pvh']."," .$_COOKIE['prbs']."," . $_COOKIE['pps'].",". $_COOKIE['ppo'].", ". $_COOKIE['pdis'].","."Bangladesh.";
                                       else echo '';
                                       }
                                        else echo '';  ?> </td>
					</tr>
					<tr>
						<td>Email:</td>
						<td><?php if($existValue!=0)
                                      {
                                      	if($existValue['email']==1) echo $_COOKIE['email'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td><h3 style="color:#338099">Payment Information Summary</h3></td>
					</tr>
					<tr>
						<td>Payment Amount:</td>
						<td><?php if($existValue3!=0)
                                      {
                                      	if($existValue3['amnt']==1) echo $_COOKIE['amnt'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Payment Date:</td>
						<td><?php if($existValue3!=0)
                                      {
                                      	if($existValue3['dop']==1) echo $_COOKIE['dop'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Receipt No:</td>
						<td><?php if($existValue3!=0)
                                      {
                                      	if($existValue3['recno']==1) echo $_COOKIE['recno'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Bank Name:</td>
						<td><?php if($existValue3!=0)
                                      {
                                      	if($existValue3['bank']==1) echo $_COOKIE['bank'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					<tr>
						<td>Bank Branch:</td>
						<td><?php if($existValue3!=0)
                                      {
                                      	if($existValue3['Branch']==1) echo $_COOKIE['Branch'];
                                       else echo '';
                                       }
                                        else echo '';  ?></td>
					</tr>
					
					<tr>
						<td><input type="button" name="previous-page" value="PREVIOUS PAGE" onclick="plink()"></td>
						<td><input type="button" name="save" value="SAVE" onclick="nlink()"></td>
					</tr>


				</table>
				<p style="color:red;"><b>Reminder:Bring old passport during collection of MRP;No correction after handover of delivery slip without fee.</b></p>
			</fieldset>
		</form>
	</div>
</body>
</html>