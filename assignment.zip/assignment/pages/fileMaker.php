<?php

$e1;
$e2;
$e3;


 if(isset($_COOKIE['fieldError']))
        {
          $e1=json_decode($_COOKIE['fieldError'],true);
          $i=count($e1);
          echo "<fieldset style='background-color:gray;width:50%;' align='center'>";
          echo "<legend>Unfinished in page One</legend>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e1[$j] </br>";
          }
          echo "</fieldset>";
       }
          
          echo "</br>";    
          echo "</br>"; 
          
   if(isset($_COOKIE['fieldError2']))
        {
          $e2=json_decode($_COOKIE['fieldError2'],true);
          $i=count($e2);
          echo "<fieldset style='background-color:gray;width:50%;' align='center'>";
          echo "<legend>Unfinished in page Two</legend>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e2[$j] </br>";
          }
          echo "</fieldset>";
       }
    
     echo "</br>";    
     echo "</br>";   
    
    if(isset($_COOKIE['fieldError3']))
        {
          $e3=json_decode($_COOKIE['fieldError3'],true);
          $i=count($e3);
          echo "<fieldset style='background-color:gray;width:50%;' align='center'>";
          echo "<legend>Unfinished in page Three</legend>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e3[$j] </br>";
          }
          echo "</fieldset>";
       }
          
     if(empty($e1) && empty($e2) && empty($e3)) {
             	
             	$myfile = fopen("0101".$_COOKIE['na'].".txt", "w") or die("Unable to open file!");
               $txt = "Name of Applicant: ".$_COOKIE['na']."\n";
               fwrite($myfile, $txt);
               
                $txt = "First Name: ".$_COOKIE['gn']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Surname: ".$_COOKIE['sn']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Nationality: ".$_COOKIE['cnationality']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Profession: ".$_COOKIE['aprofession']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Father\'s Name: ".$_COOKIE['fn']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Mother\'s Name: ".$_COOKIE['mn']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Present Address: ".$_COOKIE['vh']."," .$_COOKIE['rbs']."," . $_COOKIE['dis'].",". $_COOKIE['ps'].", ". $_COOKIE['po'].","."Bangladesh."."\n";
               fwrite($myfile, $txt);
               
                 $txt = "Permanent Address: ".$_COOKIE['pvh']."," .$_COOKIE['prbs']."," . $_COOKIE['pdis'].",". $_COOKIE['pps'].", ". $_COOKIE['ppo'].","."Bangladesh."."\n";
               fwrite($myfile, $txt);               
               
                $txt = "Birth id no: ".$_COOKIE['bid']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Passport Type: ".$_COOKIE['passtype']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Mobile No: ".$_COOKIE['mobno']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Email Address: ".$_COOKIE['email']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Payment Amount: ".$_COOKIE['amnt']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Payment Date: ".$_COOKIE['dop']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Bank: ".$_COOKIE['bank']."\n";
               fwrite($myfile, $txt);
               
                $txt = "Branch: ".$_COOKIE['Branch']."\n";
               fwrite($myfile, $txt);
               fclose($myfile);
     	
     	}

?>