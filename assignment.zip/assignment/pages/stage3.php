
<!DOCTYPE html>
<html>

	<head>
		<title>Application Form-Stage 3</title>
	</head>
	<script>
	function linkN()
	{
		location.replace("http://localhost/assignment/pages/stage2.php");
	}
	</script>
	<body>
	
		<h1> PASSPORT APPLICATION - STAGE 3 <h1>
		<h4> Fields marked with <font color="red">(*)</font> are mendatory. </h4>
		<hr>
		<?php
        if(isset($_COOKIE['fieldError3']))
        {
          $e=json_decode($_COOKIE['fieldError3'],true);
          $i=count($e);
          echo "<fieldset>";
          for($j=0;$j<$i;$j++)
          {
            echo "<font color='red'>*</font> $e[$j] </br>";
          }
          echo "</fieldset>";
        }
        if(isset($_COOKIE['existValue3'])) {
        	 $existValue3=json_decode($_COOKIE['existValue3'], true);
        }
		else {
        	$existValue3=0;
        }
       ?>
		<form action="stage3-val.php" method="POST">
		<table border = "0" width="100%" bgcolor="#eff2f7">
			<tr>
				<td>
				<table border = "0"  align = "left" width ="100%%">
				<tr>
					<th colspan = "2" align = "left"><h3>Paymemt Information</h3><th>
				</tr>
				<tr>
					<td> Paymemt Type: </td>
					<td> 
						<input type = "radio" name = "paytype">Online<br>
						<input type = "radio" name = "paytype">Non-Online
					</td>
				</tr>
				<tr>
					<td><input type = "checkbox" name = "skippayment">Skip Paymemt</td>
					<td></td>
				</tr>
				<tr>
					<td>Ammount:<font color = "red"><sup>*</sup></font></td>
					<td>
						
						<select name = "currency" value="" >
							
							<option value="BDT" selected = "selected">BDT</option>
							<option value="USD">USD</option>
							
						</select>
						<input type = "text" name = "amnt"   value=" <?php if($existValue3!=0)
                                      {
                                      	if($existValue3['amnt']==1) echo $_COOKIE['amnt'];
                                       else echo '';
                                       }
                                        else echo ''; ?>">
					</td>
				</tr>
				<tr>
					<td> Date of Paymemt:<font color = "red"><sup>*</sup></font> </td>
					<td> <input type = "text" name = "dop"  value=" <?php if($existValue3!=0)
                                      {
                                      	if($existValue3['dop']==1) echo $_COOKIE['dop'];
                                       else echo '';
                                       }
                                        else echo ''; ?>"> </td>
				</tr>
				<tr>
					<td>Receipt No:<font color = "red"><sup>*</sup></font></td>
					<td>
						<input type = "text" name = "recno"  value=" <?php if($existValue3!=0)
                                      {
                                      	if($existValue3['recno']==1) echo $_COOKIE['recno'];
                                       else echo '';
                                       }
                                        else echo ''; ?>">
					</td>				
				</tr>
				
					<td>Name of Bank:<font color = "red"><sup>*</sup></font></td>
					<td>
						<select name ="bank" value="">
							<option > <?php if($existValue3!=0)
                                      {
                                      	if($existValue3['bank']==1) echo $_COOKIE['bank'];
                                       else echo 'SELECT-';
                                       }
                                        else echo 'SELECT-'; ?></option>
							<option >BANGLADESH BANK </option>
							<option >DUTCH-BANGLA BANK </option>
							<option >DHAKA BANK </option>
							<option >CITY BANK </option>
						</select>
					</td>
				</tr>
				</tr>
				
					<td>Name of Branch:<font color = "red"><sup>*</sup></font></td>
					<td>
						<select name ="Branch" value="">
							<option >  <?php if($existValue3!=0)
                                      {
                                      	if($existValue3['Branch']==1) echo $_COOKIE['Branch'];
                                       else echo '-SELECT-';
                                       }
                                        else echo '-SELECT-'; ?></option>
							<option >BANGLADESH BANK </option>
							<option>DUTCH-BANGLA BANK </option>
							<option>DHAKA BANK </option>
							<option>CITY BANK </option>
						</select>
					</td>
				
				</table>
				</td>
				
				
				
				
			</tr>
			<tr>
				<td></td>
				<td align = "right"><br> <input type = "button" value= "PREVIOUS PAGE" align = "right" onclick="linkN()" >
						<input type = "submit" value = "SAVE & NEXT" onclick = "./pages/stage2.php" align = "right">
				</td>
			</tr>
		</table>
		</form>
		
	</body>
</html>