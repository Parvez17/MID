<?php
   
     foreach (glob("*.txt") as $filename) {
  

          echo "<fieldset style='background-color:Gainsboro ;width:50%;margin-left:300px;' align='center'>";
          echo "<legend><font color='red'>".$filename."</font></legend>";
            $myfile = fopen($filename, "r+");
            
             while(!feof($myfile))
              {
                      $line = fgets($myfile);
                      echo"<p align='center'><font color='black'>".$line."</font></p>";
                       echo "</br>";
               }
            fclose($myfile);
         // echo"<input type='button' value='Go to Page 1' align='center' style='padding:5px;' onclick='nlink()'/>";
          echo "</fieldset>";
           echo "</br>";    
          echo "</br>";
       }
          
          
          
?>